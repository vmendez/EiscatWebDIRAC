Ext.define('DIRAC.ActivityMonitor.classes.ActivityTreeModel', {
      extend : 'Ext.data.Model',
      fields : ['text', 'component'],
      alias : 'widget.activityTreemodel'
    });