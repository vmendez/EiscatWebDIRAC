/**
 * It is used by the plots images.
 */
Ext.define("DIRAC.ApplicationWizard.classes.Image", {
      extend : 'Ext.Img',
      frame : true,
      title : "No description",
      border : 3,
      style : {
        borderColor : 'white',
        borderStyle : 'solid'
      }
    });