Ext.define('DIRAC.ResourceSummary.classes.TreeModel', {
      extend : 'Ext.data.Model',
      fields : ['text', 'type', 'openResource'],
      alias : 'widget.treemodel'
    });