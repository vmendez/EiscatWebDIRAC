SimpleTasksSettings = {
    // This property is used to turn on local storage.  If set to false the php backend will be used.
    useLocalStorage: true
};
