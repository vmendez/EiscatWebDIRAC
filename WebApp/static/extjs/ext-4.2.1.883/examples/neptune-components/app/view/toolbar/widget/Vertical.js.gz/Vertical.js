Ext.define('Neptune.view.toolbar.widget.Vertical', {
    extend: 'Neptune.view.toolbar.widget.Basic',
    xtype: 'verticalToolbar',
    vertical: true
});