Ext.define('Neptune.view.tab.widget.Overflow', {
    extend: 'Ext.tab.Panel',
    xtype: 'overflowTabPanel',
    items: [
        { title: 'Tab 1', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 2', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 3', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 4', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 5', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 6', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 7', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 8', closable: true, html: NeptuneAppData.dummyText },
        { title: 'Tab 9', closable: true, html: NeptuneAppData.dummyText }
    ]
});