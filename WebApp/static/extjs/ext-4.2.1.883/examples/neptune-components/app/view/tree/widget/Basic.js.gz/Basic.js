Ext.define('Neptune.view.tree.widget.Basic', {
    extend: 'Ext.tree.Panel',
    xtype: 'basicTree',
    store: 'FileSystem',
    title: 'Basic Tree'
});