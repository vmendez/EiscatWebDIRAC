Ext.define('Neptune.view.window.widget.Basic', {
    extend: 'Ext.window.Window',
    xtype: 'basicWindow',

    title: 'Window With Buttons',
    html: NeptuneAppData.dummyText
});