Ext.define('Neptune.view.panel.widget.Basic', {
    extend: 'Ext.panel.Panel',
    xtype: 'basicPanel',

    title: 'Basic Panel',
    html: NeptuneAppData.dummyText
});