Ext.define('Neptune.view.panel.widget.Framed', {
    extend: 'Ext.panel.Panel',
    xtype: 'framedPanel',

    title: 'Framed Panel',
    frame: true,
    html: NeptuneAppData.dummyText
});