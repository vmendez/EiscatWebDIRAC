Ext.define('Neptune.view.button.widget.LargeSplit', {
    extend: 'Neptune.view.button.widget.SmallSplit',
    xtype: 'largeSplitButton',
    scale: 'large',
    text: 'Large Split'
});