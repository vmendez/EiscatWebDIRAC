Ext.define('Neptune.view.form.widget.HtmlEditor', {
    extend: 'Ext.form.field.HtmlEditor',
    xtype: 'htmlEditor',
    height: 200,
    width: 600
});