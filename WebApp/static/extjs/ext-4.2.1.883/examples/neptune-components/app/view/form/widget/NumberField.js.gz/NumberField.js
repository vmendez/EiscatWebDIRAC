Ext.define('Neptune.view.form.widget.NumberField', {
    extend: 'Ext.form.field.Number',
    xtype: 'numberField',
    fieldLabel: 'Number Field',
    value: 42
});