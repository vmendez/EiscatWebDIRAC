Ext.define('Neptune.view.panel.widget.NoTitle', {
    extend: 'Ext.panel.Panel',
    xtype: 'noTitlePanel',
    html: NeptuneAppData.dummyText
});