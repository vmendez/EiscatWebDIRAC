Ext.define('Neptune.view.tab.widget.Framed', {
    extend: 'Neptune.view.tab.widget.Basic',
    xtype: 'framedTabPanel',
    frame: true
});