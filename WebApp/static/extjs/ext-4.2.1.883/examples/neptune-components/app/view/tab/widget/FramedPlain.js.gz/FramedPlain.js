Ext.define('Neptune.view.tab.widget.FramedPlain', {
    extend: 'Neptune.view.tab.widget.Framed',
    xtype: 'framedPlainTabPanel',
    plain: true
});