Ext.define('Neptune.view.button.widget.LargeMenu', {
    extend: 'Neptune.view.button.widget.SmallMenu',
    xtype: 'largeMenuButton',
    scale: 'large',
    text: 'Large Menu'
});