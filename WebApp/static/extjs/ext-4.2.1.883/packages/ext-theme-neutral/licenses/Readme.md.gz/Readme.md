# ext-theme-neutral/licenses

This folder contains the supported licenses for third-party use.
